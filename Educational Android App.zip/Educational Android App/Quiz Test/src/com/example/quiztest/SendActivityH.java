package com.example.quiztest;

import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SendActivityH extends Activity {
	
	EditText textName;
	EditText textMessage;
	Button buttonSend;
	TextView textTo;
	TextView textSubject;
	String tot;
	String apan;
	Button sendMail;
	Button epistrofi;
	
	public void sendName(View view) {
		String name= textName.getText().toString();
		if(name.equals("")) {Toast.makeText(getApplicationContext(), 
                "�����! �������� ���� �������!", Toast.LENGTH_LONG).show();}
		
		else{
		textMessage.setText(textMessage.getText().toString()+"\n"+"����� ����: �������"+"\n"+"�������������:"+name);
		textMessage.setEnabled(false);
		buttonSend.setEnabled(false);
		textName.setEnabled(false);
		sendMail.setEnabled(true);
		epistrofi.setEnabled(true);}
		}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_send_h);
		buttonSend = (Button) findViewById(R.id.button1);
		epistrofi=(Button) findViewById(R.id.button3);
		textName = (EditText) findViewById(R.id.editText1);
		textMessage = (EditText) findViewById(R.id.editText2);
		textTo = (TextView) findViewById(R.id.textView5);
		textSubject = (TextView) findViewById(R.id.textView6);
		sendMail=(Button) findViewById(R.id.button2);
		textTo.setText("larrydev1990@gmail.com");
		textSubject.setText("����������");
		Bundle b = getIntent().getExtras();
		tot=b.getString("total");
		apan=b.getString("apantiseis");
		textMessage.setText(textMessage.getText().toString()+tot+"\n"+apan);
		textMessage.setVerticalScrollBarEnabled(true);
		textMessage.setMovementMethod(new ScrollingMovementMethod());
		epistrofi.setEnabled(false);
		textMessage.setEnabled(false);
		sendMail.setEnabled(false);
		sendMail.setOnClickListener(new OnClickListener() {
			 
			@Override
			public void onClick(View v) {
				//epistrofi.setEnabled(true);
			  String to = textTo.getText().toString();
			  String subject = textSubject.getText().toString();
			  String message = textMessage.getText().toString();
 
			  Intent email = new Intent(Intent.ACTION_SEND);
			  email.putExtra(Intent.EXTRA_EMAIL, new String[]{ to});
			  email.putExtra(Intent.EXTRA_SUBJECT, subject);
			  email.putExtra(Intent.EXTRA_TEXT, message);
 
			  //need this to prompts email client only
			  email.setType("message/rfc822");
 
			  startActivity(Intent.createChooser(email, "������� ���� Email client:"));
 
			} 
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.send_activity_h, menu);
		return true;
	}

	public void goback(View view) {
		Intent intent = new Intent(this, MathimataActivity.class);
		startActivity(intent);
	}
}
