package com.example.quiztest;
import java.util.List;

import com.example.quiztest.R;

import android.app.Activity;
import android.content.Intent;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


public class QuizActivityH extends Activity {
	List<Question> quesList;
	int score=0;
	int qid=0;
	int correct=0;
	int wrong=0;
	Question currentQ;
	TextView txtQuestion;
	RadioButton rda, rdb, rdc;
	Button butNext;
	Button butCheck;
	TextView msgSL;
	TextView msgES;
	TextView epilog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_quiz_h);
		DbHelperH db=new DbHelperH(this);
		quesList=db.getAllQuestions();
		currentQ=quesList.get(qid);
		txtQuestion=(TextView)findViewById(R.id.textView1);
		rda=(RadioButton)findViewById(R.id.radio0);
		rdb=(RadioButton)findViewById(R.id.radio1);
		rdc=(RadioButton)findViewById(R.id.radio2);
		butNext=(Button)findViewById(R.id.button1);
		butCheck=(Button)findViewById(R.id.button2);
		msgSL=(TextView)findViewById(R.id.textView2);
		msgES=(TextView)findViewById(R.id.textView3);
		epilog=(TextView)findViewById(R.id.textView4);
		setQuestionView();
		butNext.setEnabled(false);

		butCheck.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				butNext.setEnabled(true);
				butCheck.setEnabled(false); 
				
				RadioGroup grp=(RadioGroup)findViewById(R.id.radioGroup1);
				RadioButton answer=(RadioButton)findViewById(grp.getCheckedRadioButtonId());
				Log.d("yourans", currentQ.getANSWER()+" "+answer.getText());
				if(currentQ.getANSWER().equals(answer.getText()))
				{ score+=100;
				correct++;
					answer.setTextColor(Color.GREEN);
					msgSL.setText("�����!");
					msgSL.setTextColor(Color.GREEN);
					msgES.setText("�������: "+ qid +"-->"+ " ����: "+ score +" "+ " ������: "+ correct + " "+" �����������: " + wrong);
epilog.setText(epilog.getText().toString()+" ����:"+qid+","+" �����:"+answer.getText().toString()+","+" ����:"+msgSL.getText().toString()+"\n");
				}
				else{
					wrong++;
					answer.setTextColor(Color.RED);
					msgSL.setText("�����!");
					msgSL.setTextColor(Color.RED); 
					msgES.setText("�������: "+ qid +"-->"+ " ����: "+ score +" "+ " ������: "+ correct + " "+" �����������: " + wrong);
epilog.setText(epilog.getText().toString()+" ����:"+qid+","+" �����:"+answer.getText().toString()+","+" ����:"+msgSL.getText().toString()+"\n");
					}
				
					rda.setEnabled(false);
					rdb.setEnabled(false);
					rdc.setEnabled(false);
			}
	
		});
		
		
		butNext.setOnClickListener(new View.OnClickListener() {		
			@Override
			public void onClick(View v) {
				butNext.setEnabled(false);
				butCheck.setEnabled(true);
				rda.setEnabled(true);
				rdb.setEnabled(true);
				rdc.setEnabled(true);
				RadioGroup grp=(RadioGroup)findViewById(R.id.radioGroup1);
				RadioButton answer=(RadioButton)findViewById(grp.getCheckedRadioButtonId());
				Log.d("yourans", currentQ.getANSWER()+" "+answer.getText());
				answer.setTextColor(Color.BLACK);
				msgSL.setText("");
				msgES.setText("");
				if(qid<5){					
					currentQ=quesList.get(qid);
					setQuestionView();
				}else{
					butCheck.setEnabled(false);
					Intent intent = new Intent(QuizActivityH.this, ResultActivityH.class);
					Bundle b = new Bundle();
					b.putInt("score", score); //Your score
					b.putInt("qid", qid);
					b.putInt("correct", correct);
					b.putString("epilog", epilog.getText().toString()); 
					
					
					intent.putExtras(b); //Put your score to your next Intent
					startActivity(intent);
					//finish();
					
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.quiz_activity_h, menu);
		return true;
	}

	private void setQuestionView()
	{
		txtQuestion.setText(currentQ.getQUESTION());
		rda.setText(currentQ.getOPTA());
		rdb.setText(currentQ.getOPTB());
		rdc.setText(currentQ.getOPTC());
		qid++;
	}
}
