package com.example.quiztest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;



public class LevelActivity extends Activity {
	
	
	public void easy(View view) {
		Intent intent = new Intent(this, QuizActivity.class);
		startActivity(intent);
		}
	public void medium(View view) {
		Intent intent = new Intent(this, QuizActivityM.class);
		startActivity(intent);
		}
	public void hard(View view) {
		Intent intent = new Intent(this, QuizActivityH.class);
		startActivity(intent);
		}
	public void pisw(View view) {
		Intent intent = new Intent(this, MathimataActivity.class);
		startActivity(intent);
		}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_level);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.level, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
